/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.boston.employeeManagement;

import static java.lang.Integer.parseInt;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Evidance Kgothatso Mokgabudi
 */
public class frmEmployeeSalary extends javax.swing.JFrame {

    /**
     * Creates new form frmEmployeeSalary
     */
    public frmEmployeeSalary() {
        initComponents();
    }
    
    Boolean boolRecordExists=false;
    Boolean boolCreate = false;
    int employeeID;
    String firstName;
    String lastName;
    String dob;
    String department;
    int basicSalary;
    int overtime;
    int medical;
    int bonus;
    int other;
    int totalOvertime;
    int ratePerHour;
    int TotalAmount;
    
    private void mCreateEmployeeSalary()// Save employee salary
    {
       java.sql.Connection conMySQLConnectionString = null;
        String URL =  "jdbc:mysql://localhost:3306/employee";
        String User = "root";
        String Password= "password";
        
        try
        {
            
           conMySQLConnectionString = DriverManager.getConnection(URL,User,Password);
           Statement myStatement=conMySQLConnectionString.createStatement();
           String sqlinsert = "insert into employee_salary(employee_id,first_name,last_name,date_of_birth,department,basic_salary,overtime,medical,bonus,other,total_overtime,rate_per_hour)"+"values('"+employeeID+"','"+firstName+"','"+lastName+"','"+dob+"','"+department+"','"+basicSalary+"','"+overtime+"','"+medical+"','"+bonus+"','"+other+"','"+totalOvertime+"','"+ratePerHour+"')";
           myStatement.execute(sqlinsert);
           myStatement.close();
           JOptionPane.showMessageDialog(null, "Complete");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void mCheckIfItemsExistInTable()// Check if employee is saved
    {
        String strDBConnectionString = "jdbc:mysql://localhost:3306/employee";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        try 
        {
            conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           
            stStatement = conMySQLConnectionString.createStatement();
           
            String strQuery = "Select * from employee_salary Where first_name='"+firstName+"' and last_name='" +lastName+ "'and date_of_birth='"+dob+"'and basic_salary='"+basicSalary+"'and medical='"+medical+"'and bonus='"+bonus+"'and other ='"+other+"'and total_overtime='"+totalOvertime+"'and rate_per_hour ='"+ratePerHour+"'";
          
            stStatement.execute(strQuery);
           
            rs = stStatement.getResultSet();
            boolRecordExists = rs.next();           
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally 
        {
            try
            {
            stStatement.close();
            }
            catch (Exception e)
            {
                JOptionPane.showMessageDialog(null, "Connection String not Closed"+ " "+ e);
        
            }
        }
    }
    
    private void mGetEmployeeInfor()
    {
        employeeID =parseInt(txtEmployeeID.getText());
        firstName = txtFirstName.getText();
        lastName =txtSurname.getText();
        department =  txtDepartment.getText();
        dob =  txtDOB.getText(); 
        basicSalary = parseInt(txtBasicSalary.getText());
        other= parseInt(txtOther.getText());
        medical= parseInt(txtMedical.getText());
        bonus= parseInt(txtBonus.getText());
        totalOvertime= parseInt(txtTotalOvertime.getText());
        ratePerHour= parseInt(txtRatePerHour.getText());
        overtime= parseInt(txtOvertime.getText());
    }
    
    private void  mClearTextFields()// Clear TextFields
          
    {
      txtFirstName.setText("");
      txtSurname.setText("");
      txtDepartment.setText("");
      txtDOB.setText("");
      txtBasicSalary.setText("0");
      txtOvertime.setText("0");
      txtMedical.setText("0");
      txtBonus.setText("0");
      txtOther.setText("0");
      txtTotalOvertime.setText("0");
      txtRatePerHour.setText("0");
      lblOutput.setText("0.00");
      txtEmployeeID.setText("");
    }
    
    public ArrayList<EmployeeSalary> getSalaryList()
    {
        ArrayList<EmployeeSalary> salaryList = new ArrayList<EmployeeSalary>();
        String strDBConnectionString = "jdbc:mysql://localhost:3306/employee";
        String strDBUser = "root";
        String strDBPassword = "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        String query = "SELECT * FROM  `employee_salary` ";
        Statement st;
        try
        {
            conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString,strDBUser,strDBPassword);
            stStatement = conMySQLConnectionString.createStatement();
            rs = stStatement.executeQuery(query);
            
            EmployeeSalary salary;
            while(rs.next())
            {
               salary = new EmployeeSalary (rs.getInt("employee_id"),rs.getString("first_name"),rs.getString("last_name"),rs.getString("date_of_birth"),rs.getInt("basic_salary"),rs.getString("department"),rs.getInt("overtime"),rs.getInt("medical"),rs.getInt("bonus"),rs.getInt("other"),rs.getInt("total_overtime"),rs.getInt("rate_per_hour"));
               salaryList.add(salary);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return salaryList;
    }
    
    // Display Data In JTable
    public void Show_Employee_In_JTable()
    {
        ArrayList<EmployeeSalary> list = getSalaryList();
       DefaultTableModel model = (DefaultTableModel)tblEmployeeSalary.getModel();
       Object[] row = new Object[12];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getEmployeeId();
           row[1] = list.get(i).getFirstName();
           row[2] = list.get(i).getLastName();
           row[3] = list.get(i).getDateOfBirth();
           row[4] = list.get(i).getBasicSalary();
           row[5] = list.get(i).getDepartment();
           row[6] = list.get(i).getOvertime();
           row[7] = list.get(i).getMedical();
           row[8] = list.get(i).getBonus();
           row[9] = list.get(i).getOther();
           row[10] = list.get(i).getTotalOvertime();
           row[11] = list.get(i).getRatePerHour();
           
           model.addRow(row);
       }
    }
    
    private void mLoadEmployee() //Load employee from Table
    {
        String strDBConnectionString = "jdbc:mysql://localhost:3306/employee";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        
        try
        {
           conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           stStatement = conMySQLConnectionString.createStatement();
           String strQuery="Select * FROM employee_salary";
           rs=stStatement.executeQuery(strQuery);
           tblEmployeeSalary.setModel(DbUtils.resultSetToTableModel(rs));
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
      
      

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("employee?zeroDateTimeBehavior=convertToNullPU").createEntityManager();
        employeeSalaryQuery = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT e FROM EmployeeSalary e");
        employeeSalaryList = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : employeeSalaryQuery.getResultList();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtDepartment = new javax.swing.JTextField();
        txtBasicSalary = new javax.swing.JTextField();
        txtEmployeeID = new javax.swing.JTextField();
        txtFirstName = new javax.swing.JTextField();
        txtDOB = new javax.swing.JTextField();
        txtSurname = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblEmployeeSalary = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtOvertime = new javax.swing.JTextField();
        txtMedical = new javax.swing.JTextField();
        txtBonus = new javax.swing.JTextField();
        txtOther = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtTotalOvertime = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtRatePerHour = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        lblOutput = new javax.swing.JLabel();
        btnSave = new javax.swing.JButton();
        btnCalculate = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        mnuOption = new javax.swing.JMenu();
        mnuEmployeeInformation = new javax.swing.JMenuItem();
        mnuExit = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Employee Salary Information");

        jLabel1.setText("Employee id:");

        jLabel2.setText("First Name:");

        jLabel3.setText("Surname:");

        jLabel4.setText("Date of Birth:");

        jLabel5.setText("Basic Salary:");

        jLabel6.setText("Department:");

        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, employeeSalaryList, tblEmployeeSalary);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${employeeId}"));
        columnBinding.setColumnName("Employee Id");
        columnBinding.setColumnClass(Integer.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${firstName}"));
        columnBinding.setColumnName("First Name");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${lastName}"));
        columnBinding.setColumnName("Last Name");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${dateOfBirth}"));
        columnBinding.setColumnName("Date Of Birth");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${basicSalary}"));
        columnBinding.setColumnName("Basic Salary");
        columnBinding.setColumnClass(Integer.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${department}"));
        columnBinding.setColumnName("Department");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${overtime}"));
        columnBinding.setColumnName("Overtime");
        columnBinding.setColumnClass(Integer.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${medical}"));
        columnBinding.setColumnName("Medical");
        columnBinding.setColumnClass(Integer.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${bonus}"));
        columnBinding.setColumnName("Bonus");
        columnBinding.setColumnClass(Integer.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${other}"));
        columnBinding.setColumnName("Other");
        columnBinding.setColumnClass(Integer.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${totalOvertime}"));
        columnBinding.setColumnName("Total Overtime");
        columnBinding.setColumnClass(Integer.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${ratePerHour}"));
        columnBinding.setColumnName("Rate Per Hour");
        columnBinding.setColumnClass(Integer.class);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();

        tblEmployeeSalary.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblEmployeeSalaryMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblEmployeeSalary);

        jLabel7.setText("Overtime:");

        jLabel8.setText("Medical:");

        jLabel9.setText("Bonus:");

        jLabel10.setText("Other:");

        jLabel11.setText("Total Ovetime:");

        jLabel12.setText("Rate Per Hour:");

        jLabel13.setText("Total Amount:");

        btnSave.setText("Save");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });

        btnCalculate.setText("Calculate");
        btnCalculate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalculateActionPerformed(evt);
            }
        });

        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setText("Please enter the amounts");

        mnuOption.setText("Option");

        mnuEmployeeInformation.setText("Employee Information");
        mnuEmployeeInformation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuEmployeeInformationActionPerformed(evt);
            }
        });
        mnuOption.add(mnuEmployeeInformation);

        mnuExit.setText("Exit");
        mnuExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuExitActionPerformed(evt);
            }
        });
        mnuOption.add(mnuExit);

        jMenuBar1.add(mnuOption);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 701, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblOutput))
                    .addComponent(btnSave)
                    .addComponent(btnCalculate)
                    .addComponent(btnClear))
                .addGap(0, 138, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEmployeeID)
                            .addComponent(txtFirstName)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtSurname)
                            .addComponent(txtDOB)
                            .addComponent(txtBasicSalary)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(22, 22, 22)
                        .addComponent(txtDepartment)))
                .addGap(58, 58, 58)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtOvertime)
                            .addComponent(txtMedical)
                            .addComponent(txtBonus)
                            .addComponent(txtOther, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE))
                        .addGap(50, 50, 50)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(jLabel12))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtRatePerHour)
                            .addComponent(txtTotalOvertime, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE))))
                .addGap(92, 92, 92))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtEmployeeID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(txtOvertime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(txtTotalOvertime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtSurname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(txtMedical, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(txtRatePerHour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtDOB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(txtBonus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtBasicSalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(txtOther, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(lblOutput))
                        .addGap(31, 31, 31)
                        .addComponent(btnSave)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnCalculate)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnClear)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mnuExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuExitActionPerformed
        int YesOrNo = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit","Exit",JOptionPane.YES_NO_OPTION);
        
       if(YesOrNo == 0)
     {
        System.exit(0);
     }
    }//GEN-LAST:event_mnuExitActionPerformed

    private void mnuEmployeeInformationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuEmployeeInformationActionPerformed
        //Return to Employee Information
        frmEmployeeInformation EI = new frmEmployeeInformation();
        EI.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_mnuEmployeeInformationActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        if(txtEmployeeID.getText().equals(""))
    {
        JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtEmployeeID.requestFocusInWindow();
    }
 
    else if(txtFirstName.getText().equals(""))
    {
        JOptionPane.showMessageDialog(null, "This field cannot be empty");
        txtFirstName.requestFocusInWindow();
           
    }
    else if(txtSurname.getText().equals(""))
    {
        JOptionPane.showMessageDialog(null, "This field cannot be empty");
        txtSurname.requestFocusInWindow();
    }
    else if(txtDepartment.getText().equals(""))
    {
        JOptionPane.showMessageDialog(null, "This field cannot be empty");
        txtDepartment.requestFocusInWindow();
            
    }
    else if(txtDOB.getText().equals(""))
    {
        JOptionPane.showMessageDialog(null, "This field cannot be empty");
        txtDOB.requestFocusInWindow();
            
    }
    else if(txtBasicSalary.getText().equals(""))
    {
        JOptionPane.showMessageDialog(null, "This field cannot be left empty !");
        txtBasicSalary.requestFocusInWindow();
    }
    else if(basicSalary<0)
    {

        JOptionPane.showMessageDialog(null, "Please enter valid Basic Salary Amount!");
        txtBasicSalary.requestFocusInWindow();
            
    }
    else if(txtOvertime.getText().equals(""))
    {
        JOptionPane.showMessageDialog(null, "This field cannot be left empty!");
        txtOvertime.requestFocusInWindow();
    }
    else if(overtime<0)
    {

        JOptionPane.showMessageDialog(null, "Please enter valid overtime amount!");
        txtOvertime.requestFocusInWindow();
            
    }
    else if(txtMedical.getText().equals(""))
    {
        JOptionPane.showMessageDialog(null, "This field cannot be left empty!");
        txtMedical.requestFocusInWindow();
    }
    else if(medical<0)
    {

        JOptionPane.showMessageDialog(null, "Please enter valid Medical Aid Amount!");
        txtMedical.requestFocusInWindow();

    }
    else if(txtBonus.getText().equals(""))
    {
        JOptionPane.showMessageDialog(null, "This field cannot be left empty!");
        txtBonus.requestFocusInWindow();
    }
    else if(bonus<0)
    {
        JOptionPane.showMessageDialog(null, "Please enter valid Bonus Amount!");
        txtBonus.requestFocusInWindow();

    }
    else if(txtOther.getText().equals(""))
    {
        JOptionPane.showMessageDialog(null, "This field cannot be left empty!");
        txtOther.requestFocusInWindow();
    }
    else if(other<0)
    {
        JOptionPane.showMessageDialog(null, "Please enter valid Amount!");
        txtOther.requestFocusInWindow();

    }
    else if(txtTotalOvertime.getText().equals(""))
    {
        JOptionPane.showMessageDialog(null, "Please enter valid phone number!");
        txtTotalOvertime.requestFocusInWindow();
    }
    else if(totalOvertime<0)
    {
        JOptionPane.showMessageDialog(null, "Please enter valid phone number!");
        txtTotalOvertime.requestFocusInWindow();

    }
    else if(txtRatePerHour.getText().equals(""))
    {
        JOptionPane.showMessageDialog(null, "Please enter valid phone number!");
        txtRatePerHour.requestFocusInWindow();
    }
    else if(ratePerHour<0)
    {
        JOptionPane.showMessageDialog(null, "Please enter valid phone number!");
        txtRatePerHour.requestFocusInWindow();

    }
    
        else
        {
            
            mGetEmployeeInfor();
            mCheckIfItemsExistInTable();

            if(boolRecordExists==true)
            {

                boolRecordExists=false;
                JOptionPane.showMessageDialog(null, "Employee exists");
            }
            else if (boolRecordExists==false)
            {
                boolCreate = false;
                mCreateEmployeeSalary();
               // mLoadGUIControls();
                mClearTextFields();
                mLoadEmployee(); // Refresh table

            }
        }
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnCalculateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalculateActionPerformed
        // Perform calculations
        basicSalary = Integer.parseInt(txtBasicSalary.getText());
        overtime = Integer.parseInt(txtOvertime.getText());
        medical = Integer.parseInt(txtMedical.getText());
        bonus = Integer.parseInt(txtBonus.getText());
        totalOvertime = Integer.parseInt(txtTotalOvertime.getText());
        
        
        TotalAmount = (basicSalary + overtime  + bonus + totalOvertime) -( medical+other);
        lblOutput.setText(String.valueOf(TotalAmount));
    }//GEN-LAST:event_btnCalculateActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        mClearTextFields(); //Clear Text fields
        mLoadEmployee(); // Refresh Table
    }//GEN-LAST:event_btnClearActionPerformed

    private void tblEmployeeSalaryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblEmployeeSalaryMouseClicked
        // Display Selected Row In JTextFields
        int i = tblEmployeeSalary.getSelectedRow();
        TableModel model = tblEmployeeSalary.getModel();
        
        txtEmployeeID.setText(model.getValueAt(i,0).toString());
        txtFirstName.setText(model.getValueAt(i,1).toString());
        txtSurname.setText(model.getValueAt(i,2).toString());
        txtDOB.setText(model.getValueAt(i,3).toString());
        txtBasicSalary.setText(model.getValueAt(i,4).toString());
        txtDepartment.setText(model.getValueAt(i,5).toString());
        txtOvertime.setText(model.getValueAt(i,6).toString());
        txtMedical.setText(model.getValueAt(i,7).toString());
        txtBonus.setText(model.getValueAt(i,8).toString());
        txtOther.setText(model.getValueAt(i,9).toString());
        txtTotalOvertime.setText(model.getValueAt(i,10).toString());
        txtRatePerHour.setText(model.getValueAt(i,11).toString());
    }//GEN-LAST:event_tblEmployeeSalaryMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmEmployeeSalary.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmEmployeeSalary.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmEmployeeSalary.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmEmployeeSalary.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmEmployeeSalary().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCalculate;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnSave;
    private java.util.List<com.boston.employeeManagement.EmployeeSalary> employeeSalaryList;
    private javax.persistence.Query employeeSalaryQuery;
    private javax.persistence.EntityManager entityManager;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblOutput;
    private javax.swing.JMenuItem mnuEmployeeInformation;
    private javax.swing.JMenuItem mnuExit;
    private javax.swing.JMenu mnuOption;
    private javax.swing.JTable tblEmployeeSalary;
    private javax.swing.JTextField txtBasicSalary;
    private javax.swing.JTextField txtBonus;
    private javax.swing.JTextField txtDOB;
    private javax.swing.JTextField txtDepartment;
    private javax.swing.JTextField txtEmployeeID;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtMedical;
    private javax.swing.JTextField txtOther;
    private javax.swing.JTextField txtOvertime;
    private javax.swing.JTextField txtRatePerHour;
    private javax.swing.JTextField txtSurname;
    private javax.swing.JTextField txtTotalOvertime;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
