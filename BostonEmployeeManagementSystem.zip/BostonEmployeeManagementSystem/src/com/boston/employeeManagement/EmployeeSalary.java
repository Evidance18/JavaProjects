/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.boston.employeeManagement;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Evidance Kgothatso Mokgabudi
 */
@Entity
@Table(name = "employee_salary", catalog = "employee", schema = "")
@NamedQueries({
    @NamedQuery(name = "EmployeeSalary.findAll", query = "SELECT e FROM EmployeeSalary e")
    , @NamedQuery(name = "EmployeeSalary.findByEmployeeId", query = "SELECT e FROM EmployeeSalary e WHERE e.employeeId = :employeeId")
    , @NamedQuery(name = "EmployeeSalary.findByFirstName", query = "SELECT e FROM EmployeeSalary e WHERE e.firstName = :firstName")
    , @NamedQuery(name = "EmployeeSalary.findByLastName", query = "SELECT e FROM EmployeeSalary e WHERE e.lastName = :lastName")
    , @NamedQuery(name = "EmployeeSalary.findByDateOfBirth", query = "SELECT e FROM EmployeeSalary e WHERE e.dateOfBirth = :dateOfBirth")
    , @NamedQuery(name = "EmployeeSalary.findByBasicSalary", query = "SELECT e FROM EmployeeSalary e WHERE e.basicSalary = :basicSalary")
    , @NamedQuery(name = "EmployeeSalary.findByDepartment", query = "SELECT e FROM EmployeeSalary e WHERE e.department = :department")
    , @NamedQuery(name = "EmployeeSalary.findByOvertime", query = "SELECT e FROM EmployeeSalary e WHERE e.overtime = :overtime")
    , @NamedQuery(name = "EmployeeSalary.findByMedical", query = "SELECT e FROM EmployeeSalary e WHERE e.medical = :medical")
    , @NamedQuery(name = "EmployeeSalary.findByBonus", query = "SELECT e FROM EmployeeSalary e WHERE e.bonus = :bonus")
    , @NamedQuery(name = "EmployeeSalary.findByOther", query = "SELECT e FROM EmployeeSalary e WHERE e.other = :other")
    , @NamedQuery(name = "EmployeeSalary.findByTotalOvertime", query = "SELECT e FROM EmployeeSalary e WHERE e.totalOvertime = :totalOvertime")
    , @NamedQuery(name = "EmployeeSalary.findByRatePerHour", query = "SELECT e FROM EmployeeSalary e WHERE e.ratePerHour = :ratePerHour")})
public class EmployeeSalary implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "employee_id")
    private Integer employeeId;
    @Basic(optional = false)
    @Column(name = "first_name")
    private String firstName;
    @Basic(optional = false)
    @Column(name = "last_name")
    private String lastName;
    @Basic(optional = false)
    @Column(name = "date_of_birth")
    private String dateOfBirth;
    @Basic(optional = false)
    @Column(name = "basic_salary")
    private int basicSalary;
    @Basic(optional = false)
    @Column(name = "department")
    private String department;
    @Basic(optional = false)
    @Column(name = "overtime")
    private int overtime;
    @Basic(optional = false)
    @Column(name = "medical")
    private int medical;
    @Basic(optional = false)
    @Column(name = "bonus")
    private int bonus;
    @Basic(optional = false)
    @Column(name = "other")
    private int other;
    @Basic(optional = false)
    @Column(name = "total_overtime")
    private int totalOvertime;
    @Basic(optional = false)
    @Column(name = "rate_per_hour")
    private int ratePerHour;

    public EmployeeSalary() {
    }

    public EmployeeSalary(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public EmployeeSalary(Integer employeeId, String firstName, String lastName, String dateOfBirth, int basicSalary, String department, int overtime, int medical, int bonus, int other, int totalOvertime, int ratePerHour) {
        this.employeeId = employeeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.basicSalary = basicSalary;
        this.department = department;
        this.overtime = overtime;
        this.medical = medical;
        this.bonus = bonus;
        this.other = other;
        this.totalOvertime = totalOvertime;
        this.ratePerHour = ratePerHour;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        Integer oldEmployeeId = this.employeeId;
        this.employeeId = employeeId;
        changeSupport.firePropertyChange("employeeId", oldEmployeeId, employeeId);
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        String oldFirstName = this.firstName;
        this.firstName = firstName;
        changeSupport.firePropertyChange("firstName", oldFirstName, firstName);
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        String oldLastName = this.lastName;
        this.lastName = lastName;
        changeSupport.firePropertyChange("lastName", oldLastName, lastName);
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        String oldDateOfBirth = this.dateOfBirth;
        this.dateOfBirth = dateOfBirth;
        changeSupport.firePropertyChange("dateOfBirth", oldDateOfBirth, dateOfBirth);
    }

    public int getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(int basicSalary) {
        int oldBasicSalary = this.basicSalary;
        this.basicSalary = basicSalary;
        changeSupport.firePropertyChange("basicSalary", oldBasicSalary, basicSalary);
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        String oldDepartment = this.department;
        this.department = department;
        changeSupport.firePropertyChange("department", oldDepartment, department);
    }

    public int getOvertime() {
        return overtime;
    }

    public void setOvertime(int overtime) {
        int oldOvertime = this.overtime;
        this.overtime = overtime;
        changeSupport.firePropertyChange("overtime", oldOvertime, overtime);
    }

    public int getMedical() {
        return medical;
    }

    public void setMedical(int medical) {
        int oldMedical = this.medical;
        this.medical = medical;
        changeSupport.firePropertyChange("medical", oldMedical, medical);
    }

    public int getBonus() {
        return bonus;
    }

    public void setBonus(int bonus) {
        int oldBonus = this.bonus;
        this.bonus = bonus;
        changeSupport.firePropertyChange("bonus", oldBonus, bonus);
    }

    public int getOther() {
        return other;
    }

    public void setOther(int other) {
        int oldOther = this.other;
        this.other = other;
        changeSupport.firePropertyChange("other", oldOther, other);
    }

    public int getTotalOvertime() {
        return totalOvertime;
    }

    public void setTotalOvertime(int totalOvertime) {
        int oldTotalOvertime = this.totalOvertime;
        this.totalOvertime = totalOvertime;
        changeSupport.firePropertyChange("totalOvertime", oldTotalOvertime, totalOvertime);
    }

    public int getRatePerHour() {
        return ratePerHour;
    }

    public void setRatePerHour(int ratePerHour) {
        int oldRatePerHour = this.ratePerHour;
        this.ratePerHour = ratePerHour;
        changeSupport.firePropertyChange("ratePerHour", oldRatePerHour, ratePerHour);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (employeeId != null ? employeeId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EmployeeSalary)) {
            return false;
        }
        EmployeeSalary other = (EmployeeSalary) object;
        if ((this.employeeId == null && other.employeeId != null) || (this.employeeId != null && !this.employeeId.equals(other.employeeId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.boston.employeeManagement.EmployeeSalary[ employeeId=" + employeeId + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
