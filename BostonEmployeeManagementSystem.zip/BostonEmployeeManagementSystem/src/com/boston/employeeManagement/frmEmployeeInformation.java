/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.boston.employeeManagement;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Evidance Kgothatso Mokgabudi
 */
public class frmEmployeeInformation extends javax.swing.JFrame {

    /**
     * Creates new form frmEmployeeInformation
     */
    public frmEmployeeInformation() {
        initComponents();
    }
    
    Boolean boolRecordExists=false;
    Boolean boolEdit=false;
    Boolean boolCreate=false;
    String strFirstName;
    String strLastName;
    String strJobTitle;
    String strDepartment;
    String strDOB;
    String strUsername;
    String strPassword;
    int intPhoneNo; 
    int intEmployeeID;
    
    private void mGetEmployeeInfor()
    {
        strFirstName=txtFirstName.getText();
        strLastName=txtLastName.getText();
        strJobTitle=txtJobTitle.getText();
        strDepartment=txtDepartment.getText();
        strDOB=txtDoB.getText();
        strUsername=txtUsername.getText();
        strPassword=txtPassword.getText();
        intPhoneNo=Integer.parseInt(txtPhoneNumber.getText());
    }
    
    private void mSetValuesToUpperCase()
    {
        strFirstName=strFirstName.toUpperCase();
        strLastName=strLastName.toUpperCase();
        strJobTitle=strJobTitle.toUpperCase();
        strDepartment=strDepartment.toUpperCase();
        strDOB=strDOB.toUpperCase();
        strUsername=strUsername.toUpperCase();
    }
        
    private void mClearTextFields()
    {
        txtFirstName.setText("");
        txtLastName.setText("");
        txtJobTitle.setText("");
        txtDepartment.setText("");
        txtDoB.setText("");
        txtPhoneNumber.setText("");
        txtUsername.setText("");
        txtPassword.setText("");
    }
    
    private void mCheckIfItemsExistInTable() // Check if employee exists in the table
    {
        String strDBConnectionString= "jdbc:mysql://localhost:3306/employee";
        String strDBUser="root";
        String strDBPassword="password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement= null;
        ResultSet rs= null;
        try
        {
            conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString,strDBUser,strDBPassword);
            stStatement = conMySQLConnectionString.createStatement();
            String strQuery = " Select * from employee_information where first_name='" + strFirstName + "'and last_name='"
                + strLastName + "'and job_title='"+strJobTitle+ "'and department='"+strDepartment+
                "'and date_of_birth='"+strDOB+ "'and phone_number='"+intPhoneNo+"'and username='"+strUsername+
                    "'and password='"+strPassword+"'";
            stStatement.execute(strQuery);
            rs=stStatement.getResultSet();
            boolRecordExists=rs.next();
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally
        {
            try
            {
                stStatement.close();
            }
            catch (Exception e)
            {
                JOptionPane.showMessageDialog(null, "Connection String not closed" + " " + e);
            }
        }
    }
    
    private void mCreateEmployee() // Add employee to database
    {
        java.sql.Connection conMySQLConnectionString= null;
        String URL= "jdbc:mysql://localhost:3306/employee";
        String User="root";
        String Password="password";
        try
        {
            conMySQLConnectionString = DriverManager.getConnection(URL,User,Password);
            Statement myStatement = conMySQLConnectionString.createStatement();
            String sqlinsert = " insert into employee_information " + " (first_name,last_name,job_title,department,date_of_birth,phone_number,username,password) " + "values('"+ strFirstName +"','"+ strLastName +"','" +strJobTitle+ "','" +strDepartment+"','" +strDOB+"','" +intPhoneNo+"','" +strUsername+"','" +strPassword+ "')";
            myStatement.executeUpdate(sqlinsert);
            myStatement.close();
            JOptionPane.showMessageDialog(null, "Employee Added successfully");
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void mUpdateEmployee() // Update employee
    {
      {
        java.sql.Connection conMySQLConnectionString = null;
        String URL =  "jdbc:mysql://localhost:3306/employee";
        String User = "root";
        String Password= "password";
        
        try
        {
            
           conMySQLConnectionString = DriverManager.getConnection(URL,User,Password);
           Statement myStatement=conMySQLConnectionString.createStatement();
           String strQuery = "UPDATE employee_information SET first_name='"+strFirstName+"',last_name='" +strLastName+ "',job_title='"+strJobTitle+"', department='"+strDepartment+"',date_of_birth='"+strDOB+"',phone_number='"+intPhoneNo+"',password='"+strPassword+"' WHERE username='"+strUsername+"'";
           myStatement.execute(strQuery);
           myStatement.close();
           JOptionPane.showMessageDialog(null, "Updated successfully");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        
        }
      }
    }
    
    private void mLoadEmployee() //Load employee from Table
    {
        String strDBConnectionString = "jdbc:mysql://localhost:3306/employee";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        
        try
        {
           conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           stStatement = conMySQLConnectionString.createStatement();
           String strQuery="Select * FROM employee_information";
           rs=stStatement.executeQuery(strQuery);
           tblEmployeeInformation.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void mDelete() //Delete employee from table
    {
        String strDBConnectionString = "jdbc:mysql://localhost:3306/employee";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        try 
        {
            conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           
            stStatement = conMySQLConnectionString.createStatement();
           
            String strQuery = "Delete from employee_information where first_name='"+strFirstName+"' and last_name='" +strLastName+ "'and job_title='"+strJobTitle+"'and department='"+strDepartment+"'and date_of_birth='"+strDOB+"'and phone_number='"+intPhoneNo+"'and username='"+strUsername+"'and password='"+strPassword+"'";
          
            stStatement.execute(strQuery);
           
            rs = stStatement.getResultSet();
            boolRecordExists = rs.next();           
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Employee Deleted");
        }
        finally 
        {
            try
            {
                stStatement.close();
            }
            catch (Exception e)
            {
                JOptionPane.showMessageDialog(null, "Connection String not Closed"+ " "+ e);

            }
        }
    }
    
    private void mDeleteAll() //Delete all employees from Employee Information table
    {
        String strDBConnectionString = "jdbc:mysql://localhost:3306/employee";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        
        try 
        {
            conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           
            Statement myStatement = conMySQLConnectionString.createStatement();
          
            myStatement.executeUpdate(("TRUNCATE employee_information"));
            myStatement.executeUpdate(("TRUNCATE employee_salary"));
           
            myStatement.close();
            JOptionPane.showMessageDialog(null, "All data is successfully deleted");
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    
    
    
    public ArrayList<EmployeeInformation> getEmployeeList()
    {
        ArrayList<EmployeeInformation> employeeList = new ArrayList<EmployeeInformation>();
        String strDBConnectionString = "jdbc:mysql://localhost:3306/employee";
        String strDBUser = "root";
        String strDBPassword = "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        String query = "SELECT * FROM  `employee_information` ";
        Statement st;
        try
        {
            conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString,strDBUser,strDBPassword);
            stStatement = conMySQLConnectionString.createStatement();
            rs = stStatement.executeQuery(query);
            
            EmployeeInformation employee;
            while(rs.next())
            {
               employee = new EmployeeInformation (rs.getInt("employee_id"),rs.getString("first_name"),rs.getString("last_name"),rs.getString("job_title"),rs.getString("department"),rs.getString("date_of_birth"),rs.getInt("phone_number"),rs.getString("username"),rs.getString("password"));
               employeeList.add(employee);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return employeeList;
    }
    
    // Display Data In JTable
    public void Show_Employee_In_JTable()
    {
        ArrayList<EmployeeInformation> list = getEmployeeList();
       DefaultTableModel model = (DefaultTableModel)tblEmployeeInformation.getModel();
       Object[] row = new Object[9];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getEmployeeId();
           row[1] = list.get(i).getFirstName();
           row[2] = list.get(i).getLastName();
           row[3] = list.get(i).getDateOfBirth();
           row[4] = list.get(i).getPhoneNumber();
           row[5] = list.get(i).getDepartment();
           row[6] = list.get(i).getJobTitle();
           row[7] = list.get(i).getUsername();
           row[8] = list.get(i).getPassword();
           
           model.addRow(row);
       }
    }
    
    private void mLoadGUIControls()
      {
          btnUpdate.setVisible(true);
          txtFirstName.setEnabled(true);
          txtLastName.setEnabled(true);
          txtJobTitle.setEnabled(true);
          txtDepartment.setEnabled(true);
          txtDoB.setEnabled(true);
          txtPhoneNumber.setEnabled(true);
          txtUsername.setEnabled(true);
          txtPassword.setEnabled(true);
      }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("employee?zeroDateTimeBehavior=convertToNullPU").createEntityManager();
        employeeInformationQuery = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT e FROM EmployeeInformation e");
        employeeInformationList = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : employeeInformationQuery.getResultList();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtPhoneNumber = new javax.swing.JTextField();
        txtDoB = new javax.swing.JTextField();
        txtDepartment = new javax.swing.JTextField();
        txtJobTitle = new javax.swing.JTextField();
        txtLastName = new javax.swing.JTextField();
        txtFirstName = new javax.swing.JTextField();
        txtUsername = new javax.swing.JTextField();
        txtPassword = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblEmployeeInformation = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        btnAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnDeleteAll = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        mnuFile = new javax.swing.JMenu();
        munEmployeeSalary = new javax.swing.JMenuItem();
        munExit = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Employee Information form");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Employee Management System: Admin Portal");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Employee Information");

        jLabel3.setText("First Name:");

        jLabel4.setText("Last Name:");

        jLabel5.setText("Job Title:");

        jLabel6.setText("Department:");

        jLabel7.setText("Date of Birth:");

        jLabel8.setText("Phone Number:");

        jLabel9.setText("User Name:");

        jLabel10.setText("Password:");

        txtPhoneNumber.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtPhoneNumberKeyPressed(evt);
            }
        });

        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, employeeInformationList, tblEmployeeInformation);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${employeeId}"));
        columnBinding.setColumnName("Employee Id");
        columnBinding.setColumnClass(Integer.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${firstName}"));
        columnBinding.setColumnName("First Name");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${lastName}"));
        columnBinding.setColumnName("Last Name");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${jobTitle}"));
        columnBinding.setColumnName("Job Title");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${department}"));
        columnBinding.setColumnName("Department");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${dateOfBirth}"));
        columnBinding.setColumnName("Date Of Birth");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${phoneNumber}"));
        columnBinding.setColumnName("Phone Number");
        columnBinding.setColumnClass(Integer.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${username}"));
        columnBinding.setColumnName("Username");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${password}"));
        columnBinding.setColumnName("Password");
        columnBinding.setColumnClass(String.class);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        tblEmployeeInformation.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblEmployeeInformationMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblEmployeeInformation);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("Commands");

        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnDeleteAll.setText("Delete All");
        btnDeleteAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteAllActionPerformed(evt);
            }
        });

        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        mnuFile.setText("Option");

        munEmployeeSalary.setText("Employee Salary");
        munEmployeeSalary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                munEmployeeSalaryActionPerformed(evt);
            }
        });
        mnuFile.add(munEmployeeSalary);

        munExit.setText("Exit");
        munExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                munExitActionPerformed(evt);
            }
        });
        mnuFile.add(munExit);

        jMenuBar1.add(mnuFile);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(350, 350, 350))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtDoB)
                            .addComponent(txtDepartment)
                            .addComponent(txtJobTitle)
                            .addComponent(txtLastName)
                            .addComponent(txtFirstName)
                            .addComponent(txtPhoneNumber)
                            .addComponent(txtUsername)
                            .addComponent(txtPassword, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnAdd)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                                .addComponent(btnUpdate)
                                .addGap(34, 34, 34)
                                .addComponent(btnDelete)
                                .addGap(44, 44, 44)
                                .addComponent(btnDeleteAll)
                                .addGap(49, 49, 49)
                                .addComponent(btnRefresh)
                                .addGap(48, 48, 48)
                                .addComponent(btnCancel)
                                .addGap(44, 44, 44)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtJobTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtDoB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txtPhoneNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAdd)
                    .addComponent(btnUpdate)
                    .addComponent(btnDelete)
                    .addComponent(btnDeleteAll)
                    .addComponent(btnRefresh)
                    .addComponent(btnCancel))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void munEmployeeSalaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_munEmployeeSalaryActionPerformed
        //Load Employee Salary form
        frmEmployeeSalary ES = new frmEmployeeSalary();
        ES.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_munEmployeeSalaryActionPerformed

    private void munExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_munExitActionPerformed
        //Close system
        int YesOrNo = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit","Exit",JOptionPane.YES_NO_OPTION);
        
        if(YesOrNo == 0)
        {
            System.exit(0);
        }
    }//GEN-LAST:event_munExitActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        //Add Employee
        if(txtFirstName.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtFirstName.requestFocusInWindow();
           
        }
        else if(txtLastName.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtLastName.requestFocusInWindow();
            
        }
        else if(txtJobTitle.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtJobTitle.requestFocusInWindow();
            
        }
        else if(txtDepartment.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtDepartment.requestFocusInWindow();
            
        }
        else if(txtDoB.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtDoB.requestFocusInWindow();
            
            
        }
        else if(txtPhoneNumber.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Please enter valid phone number!");
            txtPhoneNumber.requestFocusInWindow();
        }
        else if(Integer.parseInt(txtPhoneNumber.getText())<=0)
        {
            JOptionPane.showMessageDialog(null, "Please enter valid phone number!");
            txtPhoneNumber.requestFocusInWindow();
            
        }
        
             else if(txtUsername.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtUsername.requestFocusInWindow();
            
        }
            else if(txtPassword.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtPassword.requestFocusInWindow();
            
        }

            else
            {
                mGetEmployeeInfor();
                mCheckIfItemsExistInTable();
                mClearTextFields();
                mSetValuesToUpperCase();

                if(boolRecordExists==true)
                {

                    boolRecordExists=true;
                    JOptionPane.showMessageDialog(null, "Employee exists");
                }
                else if (boolRecordExists==false)
                {
                    boolCreate = false;
                    mCreateEmployee();
                    mLoadGUIControls();
                    mClearTextFields();
                    mSetValuesToUpperCase();
                   
                }
            }
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        // Undate button
        if(txtFirstName.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtFirstName.requestFocusInWindow();
           
        }
        else if(txtLastName.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtLastName.requestFocusInWindow();
            
        }
        else if(txtJobTitle.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtJobTitle.requestFocusInWindow();
            
        }
        else if(txtDepartment.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtDepartment.requestFocusInWindow();
            
        }
        else if(txtDoB.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtDoB.requestFocusInWindow();
            
            
        }
        else if(txtPhoneNumber.getText().equals("") || !(Pattern.matches("^[0-9.]+$", txtPhoneNumber.getText())))
        {
            JOptionPane.showMessageDialog(null, "Please enter valid phone number!");
            txtPhoneNumber.requestFocusInWindow();
        }
        else if(txtPhoneNumber.getText().equals(0))
        {
            JOptionPane.showMessageDialog(null, "Please enter valid phone number!");
            txtPhoneNumber.requestFocusInWindow();
            
        }
        
             else if(txtUsername.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtUsername.requestFocusInWindow();
            
        }
            else if(txtPassword.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtPassword.requestFocusInWindow();
            
        }
             
          
            else
            {
                mGetEmployeeInfor();
               

                if(boolRecordExists==true)
                {

                    boolRecordExists=false;
                    JOptionPane.showMessageDialog(null, "Already registered");
                }
                else if (boolRecordExists==false)
                {
                    boolCreate = false;
                    mGetEmployeeInfor();
                    
                    mUpdateEmployee();
                    mClearTextFields();
                    mSetValuesToUpperCase();
                }
            }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
    // Refresh table
    mLoadEmployee();
    mClearTextFields();
    }//GEN-LAST:event_btnRefreshActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        //Clear TextFields button
        mClearTextFields();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        //Delete Employee 
        int YesOrNo = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this record?","Delete",JOptionPane.YES_NO_OPTION);
        
        if(YesOrNo == 0)
        {
            if(txtFirstName.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtFirstName.requestFocusInWindow();
           
        }
        else if(txtLastName.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtLastName.requestFocusInWindow();
            
        }
        else if(txtJobTitle.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtJobTitle.requestFocusInWindow();
            
        }
        else if(txtDepartment.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtDepartment.requestFocusInWindow();
            
        }
        else if(txtDoB.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtDoB.requestFocusInWindow();
            
            
        }
        else if(txtPhoneNumber.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Please enter valid phone number!");
            txtPhoneNumber.requestFocusInWindow();
        }
                
        else if(txtUsername.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtUsername.requestFocusInWindow();
            
        }
            else if(txtPassword.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "This field cannot be empty");
            txtPassword.requestFocusInWindow();
            
        }
             
          
            else
            {
                mGetEmployeeInfor();
                mDelete();
                mClearTextFields();

                if(boolRecordExists==true)
                {

                    boolRecordExists=false;
                    
                }
                else if (boolRecordExists==false)
                {
                    boolCreate = false;
  
                    mGetEmployeeInfor();

                }
            }
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnDeleteAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteAllActionPerformed
        //Delete all records from database
        int YesOrNo = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete all records?","Delete All",JOptionPane.YES_NO_OPTION);
        
        if(YesOrNo == 0)
        {
            mDeleteAll();
        }
    }//GEN-LAST:event_btnDeleteAllActionPerformed

    private void tblEmployeeInformationMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblEmployeeInformationMouseClicked
        // Display Selected Row In JTextFields
        int i = tblEmployeeInformation.getSelectedRow();
        TableModel model = tblEmployeeInformation.getModel();
        
        txtFirstName.setText(model.getValueAt(i,1).toString());
        txtLastName.setText(model.getValueAt(i,2).toString());
        txtJobTitle.setText(model.getValueAt(i,3).toString());
        txtDepartment.setText(model.getValueAt(i,4).toString());
        txtDoB.setText(model.getValueAt(i,5).toString());
        txtPhoneNumber.setText(model.getValueAt(i,6).toString());
        txtUsername.setText(model.getValueAt(i,7).toString());
        txtPassword.setText(model.getValueAt(i,8).toString());
    }//GEN-LAST:event_tblEmployeeInformationMouseClicked

    private void txtPhoneNumberKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPhoneNumberKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhoneNumberKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmEmployeeInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmEmployeeInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmEmployeeInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmEmployeeInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmEmployeeInformation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnDeleteAll;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnUpdate;
    private java.util.List<com.boston.employeeManagement.EmployeeInformation> employeeInformationList;
    private javax.persistence.Query employeeInformationQuery;
    private javax.persistence.EntityManager entityManager;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenu mnuFile;
    private javax.swing.JMenuItem munEmployeeSalary;
    private javax.swing.JMenuItem munExit;
    private javax.swing.JTable tblEmployeeInformation;
    private javax.swing.JTextField txtDepartment;
    private javax.swing.JTextField txtDoB;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtJobTitle;
    private javax.swing.JTextField txtLastName;
    private javax.swing.JTextField txtPassword;
    private javax.swing.JTextField txtPhoneNumber;
    private javax.swing.JTextField txtUsername;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
