/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.boston.employeeManagement;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Evidance Kgothatso Mokgabudi
 */
@Entity
@Table(name = "employee_information", catalog = "employee", schema = "")
@NamedQueries({
    @NamedQuery(name = "EmployeeInformation.findAll", query = "SELECT e FROM EmployeeInformation e")
    , @NamedQuery(name = "EmployeeInformation.findByEmployeeId", query = "SELECT e FROM EmployeeInformation e WHERE e.employeeId = :employeeId")
    , @NamedQuery(name = "EmployeeInformation.findByFirstName", query = "SELECT e FROM EmployeeInformation e WHERE e.firstName = :firstName")
    , @NamedQuery(name = "EmployeeInformation.findByLastName", query = "SELECT e FROM EmployeeInformation e WHERE e.lastName = :lastName")
    , @NamedQuery(name = "EmployeeInformation.findByJobTitle", query = "SELECT e FROM EmployeeInformation e WHERE e.jobTitle = :jobTitle")
    , @NamedQuery(name = "EmployeeInformation.findByDepartment", query = "SELECT e FROM EmployeeInformation e WHERE e.department = :department")
    , @NamedQuery(name = "EmployeeInformation.findByDateOfBirth", query = "SELECT e FROM EmployeeInformation e WHERE e.dateOfBirth = :dateOfBirth")
    , @NamedQuery(name = "EmployeeInformation.findByPhoneNumber", query = "SELECT e FROM EmployeeInformation e WHERE e.phoneNumber = :phoneNumber")
    , @NamedQuery(name = "EmployeeInformation.findByUsername", query = "SELECT e FROM EmployeeInformation e WHERE e.username = :username")
    , @NamedQuery(name = "EmployeeInformation.findByPassword", query = "SELECT e FROM EmployeeInformation e WHERE e.password = :password")})
public class EmployeeInformation implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "employee_id")
    private Integer employeeId;
    @Basic(optional = false)
    @Column(name = "first_name")
    private String firstName;
    @Basic(optional = false)
    @Column(name = "last_name")
    private String lastName;
    @Basic(optional = false)
    @Column(name = "job_title")
    private String jobTitle;
    @Basic(optional = false)
    @Column(name = "department")
    private String department;
    @Basic(optional = false)
    @Column(name = "date_of_birth")
    private String dateOfBirth;
    @Basic(optional = false)
    @Column(name = "phone_number")
    private int phoneNumber;
    @Basic(optional = false)
    @Column(name = "username")
    private String username;
    @Basic(optional = false)
    @Column(name = "password")
    private String password;

    public EmployeeInformation() {
    }

    public EmployeeInformation(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public EmployeeInformation(Integer employeeId, String firstName, String lastName, String jobTitle, String department, String dateOfBirth, int phoneNumber, String username, String password) {
        this.employeeId = employeeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.jobTitle = jobTitle;
        this.department = department;
        this.dateOfBirth = dateOfBirth;
        this.phoneNumber = phoneNumber;
        this.username = username;
        this.password = password;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        Integer oldEmployeeId = this.employeeId;
        this.employeeId = employeeId;
        changeSupport.firePropertyChange("employeeId", oldEmployeeId, employeeId);
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        String oldFirstName = this.firstName;
        this.firstName = firstName;
        changeSupport.firePropertyChange("firstName", oldFirstName, firstName);
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        String oldLastName = this.lastName;
        this.lastName = lastName;
        changeSupport.firePropertyChange("lastName", oldLastName, lastName);
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        String oldJobTitle = this.jobTitle;
        this.jobTitle = jobTitle;
        changeSupport.firePropertyChange("jobTitle", oldJobTitle, jobTitle);
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        String oldDepartment = this.department;
        this.department = department;
        changeSupport.firePropertyChange("department", oldDepartment, department);
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        String oldDateOfBirth = this.dateOfBirth;
        this.dateOfBirth = dateOfBirth;
        changeSupport.firePropertyChange("dateOfBirth", oldDateOfBirth, dateOfBirth);
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        int oldPhoneNumber = this.phoneNumber;
        this.phoneNumber = phoneNumber;
        changeSupport.firePropertyChange("phoneNumber", oldPhoneNumber, phoneNumber);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        String oldUsername = this.username;
        this.username = username;
        changeSupport.firePropertyChange("username", oldUsername, username);
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        String oldPassword = this.password;
        this.password = password;
        changeSupport.firePropertyChange("password", oldPassword, password);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (employeeId != null ? employeeId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EmployeeInformation)) {
            return false;
        }
        EmployeeInformation other = (EmployeeInformation) object;
        if ((this.employeeId == null && other.employeeId != null) || (this.employeeId != null && !this.employeeId.equals(other.employeeId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.boston.employeeManagement.EmployeeInformation[ employeeId=" + employeeId + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
