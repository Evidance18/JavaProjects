/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stemsentertainmentcompany;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Lwandile
 */
public class RegisterNewMovie extends javax.swing.JInternalFrame {

    /**
     * Creates new form RegisterNewMovie
     */
    public RegisterNewMovie() {
        initComponents();
    }
    
    Boolean boolRecordExists = false;
    Boolean boolEdit = false;
    Boolean boolCreate = false;
    String strMovieName;
    String strGenre;
    int intMovieID;
       
    private void mClearVariables()
    {
    strMovieName="";
    strGenre="";
    }
    private void mGetValuesFromGUI()
    {
        strMovieName = txtMoviename.getText();
        strGenre = txtGenre.getText();
        
    }
    
    private void mSetValuesToUpperCase()
    {
        strMovieName = strMovieName.toUpperCase();
        strGenre = strGenre.toUpperCase();
      
    }

    private void mSetValuesInGUI()
    {
       txtMoviename.setText(strMovieName);
       txtGenre.setText(strGenre);
    }
    
    private void mClearTextFields()
    {
        txtMoviename.setText("");
        txtGenre.setText("");
    }
        private void mcheckIfItemExistinTable()
    {
        String strDBConnectionString = "jdbc:mysql://localhost:3306/stems";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        try 
        {
           conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           stStatement = conMySQLConnectionString.createStatement();
           String strQuery = "Select * from movie_catalog where Movie_name='" +strMovieName+ "'and Genre='"+strGenre+"'";
           stStatement.execute(strQuery);
           rs = stStatement.getResultSet();
           boolRecordExists = rs.next();           
                   }catch (Exception e){
                       JOptionPane.showMessageDialog(null, e);
                   }finally {
            try{
            stStatement.close();
            }catch (Exception e){
                       JOptionPane.showMessageDialog(null, "Connection String not Closed"+ " "+ e);
        }
        }
    }
      private void mCreateMovie()
    {
        java.sql.Connection conMySQLConnectionString = null;
        String URL =  "jdbc:mysql://localhost:3306/stems";
        String User = "root";
        String Password= "password";
        
        try
        {
           conMySQLConnectionString = DriverManager.getConnection(URL,User,Password);
           Statement myStatement=conMySQLConnectionString.createStatement();
           String sqlinsert = "insert into Movie_catalog(Movie_name,Genre)"+"values('"+strMovieName+"','"+strGenre+"')";
           myStatement.execute(sqlinsert);
           myStatement.close();
           JOptionPane.showMessageDialog(null, "Complete");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
      
      private void mLoadMovieName()
    {
        String strDBConnectionString = "jdbc:mysql://localhost:3306/stems";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        
        try
        {
           conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           stStatement = conMySQLConnectionString.createStatement();
           String strQuery="Select Movie_Name FROM movie_catalog";
           stStatement.execute(strQuery);
           rs=stStatement.getResultSet();
           
           while(rs.next())
           {
               cboMoviename.addItem(rs.getString(1));
               
           }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally
        {
            try
            {
                stStatement.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "Connection string not closed"+" "+e);
            }
        }
    }
         private void mUpdateMovie()
    {
        String strDBConnectionString = "jdbc:mysql://localhost:3306/stems";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        
        try{
           conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           stStatement = conMySQLConnectionString.createStatement();
           String strQuery = "Update Movie_catalog SET Movie_Name='"+strMovieName+"',Genre='"+strGenre+"'WHERE ID="+intMovieID;
           stStatement.execute(strQuery);
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally{
            try
            {
                stStatement.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"Connection string not closed!"+" "+ e);
            }
        }
    } 
      
       private void mClearComboBox()
    {
        String[] arrArray = new String[0];
        javax.swing.DefaultComboBoxModel model = new javax.swing.DefaultComboBoxModel(arrArray);
        cboMoviename.setModel(model);
    }
    private void mDeleteMovie()
    {
       String strDBConnectionString = "jdbc:mysql://localhost:3306/stems";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        
        try{
           conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword); 
           
           String strQuery= "Delete from Movie_catalog where Movie_Name='"+strMovieName+"'and Genre='"+strGenre+"'and ID="+intMovieID;
           stStatement=conMySQLConnectionString.prepareStatement(strQuery);
           stStatement.execute(strQuery);
        }
        catch(Exception e)
        {
            
            JOptionPane.showMessageDialog(null, e);
        }
    finally{
            try{
                stStatement.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "Connection string not closed!"+" " +e);
            }
        }
    }
      private void mReadMovieDetails()
      {
         String strDBConnectionString = "jdbc:mysql://localhost:3306/stems";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        
        try
        {
           conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           stStatement = conMySQLConnectionString.createStatement();
           String strQuery="Select ID,Movie_Name,Genre from movie_catalog where movie_Name='"+ cboMoviename.getSelectedItem().toString()+"'";
           stStatement.execute(strQuery);
           rs=stStatement.getResultSet();
           
           while(rs.next())
           {
               intMovieID = rs.getInt(1);
               strMovieName= rs.getString(2);
               strGenre = rs.getString(3);
               
               
           }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally
        {
            try
            {
                stStatement.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "Connection string not closed"+" "+e);
            }  
      }
      }
      private void mLoadGUIControls()
      {
          txtMoviename.setEnabled(false);
          txtGenre.setEnabled(false);
          cboMoviename.setEnabled(true);
          btnCreate.setEnabled(true);
          btnLoad.setEnabled(true);
          btnEdit.setEnabled(true);
          btnSave.setEnabled(false);
          btnDelete.setEnabled(false);
      }
      private void mEditGUIControls()
      {
          txtMoviename.setEnabled(true);
          txtGenre.setEnabled(true);
          cboMoviename.setEnabled(false);
          btnCreate.setEnabled(false);
          btnLoad.setEnabled(false);
          btnEdit.setEnabled(false);
          btnSave.setEnabled(true);
          btnDelete.setEnabled(true);
      }
      private void mSaveGUIControls()
      { 
          txtMoviename.setEnabled(false);
          txtGenre.setEnabled(false);
         cboMoviename.setEnabled(true);
          btnCreate.setEnabled(true);
          btnLoad.setEnabled(true);
          btnEdit.setEnabled(true);
          btnSave.setEnabled(false);
          btnDelete.setEnabled(false);
      }
      private void mCreateGUIControls()
      {
         txtMoviename.setEnabled(true);
           txtGenre.setEnabled(true);
          cboMoviename.setEnabled(false);
          btnCreate.setEnabled(false);
          btnLoad.setEnabled(false);
          btnEdit.setEnabled(false);
          btnSave.setEnabled(true);
          btnDelete.setEnabled(true);
      }
      private void mDeleteControls()
      {   
          txtMoviename.setEnabled(false);
          txtGenre.setEnabled(false);
         cboMoviename.setEnabled(true);
          btnCreate.setEnabled(true);
          btnLoad.setEnabled(true);
          btnEdit.setEnabled(true);
          btnSave.setEnabled(false);
          btnDelete.setEnabled(false);
      }
           
         
      
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnCreate = new javax.swing.JButton();
        btnLoad = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtMoviename = new javax.swing.JTextField();
        txtGenre = new javax.swing.JTextField();
        cboMoviename = new javax.swing.JComboBox<>();

        setClosable(true);
        setIconifiable(true);
        setTitle("Register New Movie");

        btnCreate.setText("Create");
        btnCreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreateActionPerformed(evt);
            }
        });

        btnLoad.setText("Load");
        btnLoad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoadActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnSave.setText("Save");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });

        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        jLabel1.setText("Movie Name");

        jLabel2.setText("Genre");

        cboMoviename.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboMovienameActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cboMoviename, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtMoviename)
                            .addComponent(txtGenre, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)))
                    .addComponent(btnCreate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnLoad, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnEdit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSave, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDelete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(65, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(cboMoviename, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtMoviename, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtGenre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addComponent(btnCreate)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnLoad)
                .addGap(18, 18, 18)
                .addComponent(btnEdit)
                .addGap(18, 18, 18)
                .addComponent(btnSave)
                .addGap(18, 18, 18)
                .addComponent(btnDelete)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoadActionPerformed
       mReadMovieDetails();
       mSetValuesInGUI();
       mLoadGUIControls();
       mLoadMovieName();
    }//GEN-LAST:event_btnLoadActionPerformed

    private void btnCreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateActionPerformed
         mCreateGUIControls();
        txtMoviename.requestFocusInWindow();
        btnDelete.setText("Cancel");
        boolCreate= true;
    }//GEN-LAST:event_btnCreateActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
       mReadMovieDetails();
       mSetValuesInGUI();
       mEditGUIControls();
       txtMoviename.requestFocusInWindow();
       btnDelete.setText("Cancel");
       boolEdit = true;
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
   if(boolCreate==true)
       {
           if(txtMoviename.getText().equals(""))
           {
               JOptionPane.showMessageDialog(null, "The field can not be left empty");
               txtMoviename.requestFocusInWindow();
           }
           else if(txtGenre.getText().equals("")){
               JOptionPane.showMessageDialog(null, "The field can not be left empty");
               txtGenre.requestFocusInWindow();
           }
           else
           {
            mGetValuesFromGUI();
            mSetValuesToUpperCase();
            mcheckIfItemExistinTable();
             
            if(boolRecordExists==true)
            {
                
             boolRecordExists=false;
             JOptionPane.showMessageDialog(null, "Movie already Exists");
            }
            else if (boolRecordExists==false)
            {
                boolCreate = false;
                mCreateMovie();
                mClearTextFields();
                mClearVariables();
                mClearComboBox();
                mLoadMovieName();
                mLoadGUIControls();
            }}}
       btnDelete.setText("Delete");
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
    if("Delete".equals(btnDelete.getText()))
{
    
    mReadMovieDetails();
    mDeleteMovie();
    mClearComboBox();
    mClearVariables();
    mLoadMovieName();
}
else if("Cancel".equals(btnDelete.getText()))
{
    mClearTextFields();
    mClearVariables();
    mClearComboBox();
    mLoadMovieName();
    mLoadGUIControls();
    btnDelete.setText("Delete");
}
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void cboMovienameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboMovienameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboMovienameActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCreate;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnLoad;
    private javax.swing.JButton btnSave;
    private javax.swing.JComboBox<String> cboMoviename;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField txtGenre;
    private javax.swing.JTextField txtMoviename;
    // End of variables declaration//GEN-END:variables
}
