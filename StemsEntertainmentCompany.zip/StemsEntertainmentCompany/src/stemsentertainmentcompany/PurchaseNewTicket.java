/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stemsentertainmentcompany;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Lwandile
 */
public class PurchaseNewTicket extends javax.swing.JInternalFrame {

    /**
     * Creates new form PurchaseNewTicket
     */
    public PurchaseNewTicket() {
        initComponents();
         mLoadMovieName();
         mLoadTime();
    }
 Boolean boolRecordExists = false;
    Boolean boolEdit = false;
    Boolean boolCreate = false;
    String strMovieName;
    String strTime;
    int intMovieID;
    int intTicketNo;
       
    private void mClearVariables()
    {
   
   intTicketNo=Integer.parseInt("");
    }
    private void mGetValuesFromGUI()
    {
        strMovieName = cboMoviename.getSelectedItem().toString();
        strTime = cboTime.getSelectedItem().toString();
        intTicketNo = Integer.parseInt(txtTicketNo.getText());
    }


    private void mSetValuesInGUI()
    {
       cboMoviename.getSelectedItem();
       cboTime.getSelectedItem();
    }
    
    private void mClearTextFields()
    {
       
        txtTicketNo.setText("");
    }
        private void mcheckIfItemExistinTable()
    {
        String strDBConnectionString = "jdbc:mysql://localhost:3306/stems";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        try 
        {
           conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           stStatement = conMySQLConnectionString.createStatement();
           String strQuery = "Select * from booked_sessions where Ticket_Number='"+intTicketNo+"' and Movie_name='" +strMovieName+ "'and Time_Booked='"+strTime+"'";
           stStatement.execute(strQuery);
           rs = stStatement.getResultSet();
           boolRecordExists = rs.next();           
                   }catch (Exception e){
                       JOptionPane.showMessageDialog(null, e);
                   }finally {
            try{
            stStatement.close();
            }catch (Exception e){
                       JOptionPane.showMessageDialog(null, "Connection String not Closed"+ " "+ e);
        }
        }
    }
      private void mCreateTicket()
    {
        java.sql.Connection conMySQLConnectionString = null;
        String URL =  "jdbc:mysql://localhost:3306/stems";
        String User = "root";
        String Password= "password";
        
        try
        {
           conMySQLConnectionString = DriverManager.getConnection(URL,User,Password);
           Statement myStatement=conMySQLConnectionString.createStatement();
           String sqlinsert = "insert into booked_sessions(Ticket_number,Movie_name,Time_booked)"+"values('"+intTicketNo+"','"+strMovieName+"','"+strTime+"')";
           myStatement.execute(sqlinsert);
           myStatement.close();
           JOptionPane.showMessageDialog(null, "Complete");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
      
      private void mLoadMovieName()
    {
        String strDBConnectionString = "jdbc:mysql://localhost:3306/stems";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        
        try
        {
           conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           stStatement = conMySQLConnectionString.createStatement();
           String strQuery="Select Movie_Name FROM movie_catalog";
           stStatement.execute(strQuery);
           rs=stStatement.getResultSet();
           
           while(rs.next())
           {
               cboMoviename.addItem(rs.getString(1));
               
           }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally
        {
            try
            {
                stStatement.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "Connection string not closed"+" "+e);
            }
        }
    }
               private void mLoadTime()
    {
        String strDBConnectionString = "jdbc:mysql://localhost:3306/stems";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        
        try
        {
           conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           stStatement = conMySQLConnectionString.createStatement();
           String strQuery="Select Times FROM times";
           stStatement.execute(strQuery);
           rs=stStatement.getResultSet();
           
           while(rs.next())
           {
               cboTime.addItem(rs.getString(1));
               
           }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally
        {
            try
            {
                stStatement.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "Connection string not closed"+" "+e);
            }
        }
    }

      
         private void mUpdateMovie()
    {
        String strDBConnectionString = "jdbc:mysql://localhost:3306/stems";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        
        try{
           conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           stStatement = conMySQLConnectionString.createStatement();
           String strQuery = "Update booked_sessions SET Ticket_Number='"+intTicketNo+"',Movie_Name='"+strMovieName+"',Time_Booked='"+strTime+"'WHERE ID="+intMovieID;
           stStatement.execute(strQuery);
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally{
            try
            {
                stStatement.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"Connection string not closed!"+" "+ e);
            }
        }
    } 
      
       private void mClearComboBox()
    {
        String[] arrArray = new String[0];
        javax.swing.DefaultComboBoxModel model = new javax.swing.DefaultComboBoxModel(arrArray);
        cboMoviename.setModel(model);
    }
          private void mClearComboBox1()
    {
        String[] arrArray = new String[0];
        javax.swing.DefaultComboBoxModel model = new javax.swing.DefaultComboBoxModel(arrArray);
        cboTime.setModel(model);
    }
    private void mDeleteMovie()
    {
       String strDBConnectionString = "jdbc:mysql://localhost:3306/stems";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        
        try{
           conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword); 
           
           String strQuery= "Delete from booked_sessions where  Ticket_Number='"+intTicketNo+"'and Movie_Name='"+strMovieName+"'and Time_Booked='"+strTime+"'and ID="+intMovieID;
           stStatement=conMySQLConnectionString.prepareStatement(strQuery);
           stStatement.execute(strQuery);
        }
        catch(Exception e)
        {
            
            JOptionPane.showMessageDialog(null, e);
        }
    finally{
            try{
                stStatement.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "Connection string not closed!"+" " +e);
            }
        }
    }
      private void mReadMovieDetails()
      {
         String strDBConnectionString = "jdbc:mysql://localhost:3306/stems";
        String strDBUser = "root";
        String strDBPassword= "password";
        java.sql.Connection conMySQLConnectionString;
        Statement stStatement = null;
        ResultSet rs= null;
        
        try
        {
           conMySQLConnectionString = DriverManager.getConnection(strDBConnectionString, strDBUser, strDBPassword);
           stStatement = conMySQLConnectionString.createStatement();
           String strQuery="Select ID,Ticket_Number,Movie_Name,Time_booked from Booked_Sessions where movie_Name='"+ cboMoviename.getSelectedItem().toString()+"'";
           stStatement.execute(strQuery);
           rs=stStatement.getResultSet();
           
           while(rs.next())
           {
               intMovieID = rs.getInt(1);
               intTicketNo = Integer.parseInt(rs.getString(2));
               strMovieName= rs.getString(3);
               strTime = rs.getString(4);
               
               
           }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally
        {
            try
            {
                stStatement.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "Connection string not closed"+" "+e);
            }  
      }
      }
      private void mLoadGUIControls()
      {
          
          txtTicketNo.setEnabled(true);
          cboTime.setEnabled(true);
          cboMoviename.setEnabled(true);
          btnBook.setEnabled(true);
          btnLoad.setEnabled(true);
          btnEdit.setEnabled(true);
          btnSave.setEnabled(false);
          btnDelete.setEnabled(false);
      }
      private void mEditGUIControls()
      {
           txtTicketNo.setEnabled(true);
          cboTime.setEnabled(true);
          cboMoviename.setEnabled(true);
          btnBook.setEnabled(false);
          btnLoad.setEnabled(false);
          btnEdit.setEnabled(false);
          btnSave.setEnabled(true);
          btnDelete.setEnabled(true);
      }
      private void mSaveGUIControls()
      { 
          txtTicketNo.setEnabled(false);
          cboTime.setEnabled(true);
          cboMoviename.setEnabled(true);
          btnBook.setEnabled(true);
          btnLoad.setEnabled(true);
          btnEdit.setEnabled(true);
          btnSave.setEnabled(false);
          btnDelete.setEnabled(false);
      }
      private void mCreateGUIControls()
      {
          txtTicketNo.setEnabled(true);
          cboTime.setEnabled(true);
          cboMoviename.setEnabled(true);
          btnBook.setEnabled(false);
          btnLoad.setEnabled(false);
          btnEdit.setEnabled(false);
          btnSave.setEnabled(true);
          btnDelete.setEnabled(true);
      }
      private void mDeleteControls()
      {   
          txtTicketNo.setEnabled(false);
          cboTime.setEnabled(true);
          cboMoviename.setEnabled(true);
          btnBook.setEnabled(true);
          btnLoad.setEnabled(true);
          btnEdit.setEnabled(true);
          btnSave.setEnabled(false);
          btnDelete.setEnabled(false);
      }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnBook = new javax.swing.JButton();
        btnLoad = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtTicketNo = new javax.swing.JTextField();
        cboMoviename = new javax.swing.JComboBox<>();
        cboTime = new javax.swing.JComboBox<>();

        setClosable(true);
        setIconifiable(true);
        setTitle("Purchase New Ticket");

        btnBook.setText("Book");
        btnBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBookActionPerformed(evt);
            }
        });

        btnLoad.setText("Load");
        btnLoad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoadActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnSave.setText("Save");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });

        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        jLabel2.setText("Ticket Number");

        cboTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTimeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cboMoviename, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                        .addComponent(txtTicketNo, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnBook, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnLoad, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnEdit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSave, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDelete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cboTime, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(70, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(cboMoviename, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cboTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtTicketNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addComponent(btnBook)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnLoad)
                .addGap(18, 18, 18)
                .addComponent(btnEdit)
                .addGap(18, 18, 18)
                .addComponent(btnSave)
                .addGap(18, 18, 18)
                .addComponent(btnDelete)
                .addContainerGap(86, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBookActionPerformed
        mCreateGUIControls();
        txtTicketNo.requestFocusInWindow();
        btnDelete.setText("Cancel");
        boolCreate= true;
    }//GEN-LAST:event_btnBookActionPerformed

    private void btnLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoadActionPerformed

        mSetValuesInGUI();
        mLoadGUIControls();
        mLoadMovieName();
        mLoadTime();
    }//GEN-LAST:event_btnLoadActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
        mReadMovieDetails();
        mSetValuesInGUI();
        mEditGUIControls();
        txtTicketNo.requestFocusInWindow();
        btnDelete.setText("Cancel");
        boolEdit = true;
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        if(boolCreate==true)
        {
            if(cboMoviename.getSelectedItem().equals(""))
            {
                JOptionPane.showMessageDialog(null, "The field can not be left empty");
                cboMoviename.requestFocusInWindow();
            }
            else if(cboTime.getSelectedItem().equals("")){
                JOptionPane.showMessageDialog(null, "The field can not be left empty");
                cboTime.requestFocusInWindow();
            }
            else if(txtTicketNo.getText().equals("")){
                JOptionPane.showMessageDialog(null, "The field can not be left empty");
                txtTicketNo.requestFocusInWindow();
            }
            else
            {
                mGetValuesFromGUI();
                //mSetValuesToUpperCase();
                mcheckIfItemExistinTable();

                if(boolRecordExists==true)
                {

                    boolRecordExists=false;
                    JOptionPane.showMessageDialog(null, "Already Booked");
                }
                else if (boolRecordExists==false)
                {
                    boolCreate = false;
                    mCreateTicket();
                    mClearTextFields();
                    mClearVariables();
                    mClearComboBox();
                    mClearComboBox1();
                    mLoadMovieName();
                    mLoadGUIControls();
                }}}
                btnDelete.setText("Delete");
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        if("Delete".equals(btnDelete.getText()))
        {

            mReadMovieDetails();
            mDeleteMovie();
            mClearComboBox();
            mClearComboBox1();
            mClearVariables();
            mLoadMovieName();
        }
        else if("Cancel".equals(btnDelete.getText()))
        {
            mClearTextFields();
            mClearVariables();
            mClearComboBox();
            mLoadMovieName();
            mLoadGUIControls();
            btnDelete.setText("Delete");
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void cboTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTimeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboTimeActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBook;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnLoad;
    private javax.swing.JButton btnSave;
    private javax.swing.JComboBox<String> cboMoviename;
    private javax.swing.JComboBox<String> cboTime;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField txtTicketNo;
    // End of variables declaration//GEN-END:variables
}
